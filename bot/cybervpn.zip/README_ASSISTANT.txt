Refactored structure (added by assistant)
- admin/           -> admin pages (cs.php, bodcash.php, deposit_settings.php)
- user/            -> user-facing pages
- core/            -> core app files
- config/          -> constants.php (DEFAULT_QRIS) and other config
Notes:
- Lines mentioning 'ewallet' have been commented out with prefix // REMOVED_EWALLET
- Data files are under data/ for quick setup (balances, cs_contacts, logs)
