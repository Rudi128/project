<?php
// admin/deposit_settings.php - admin can adjust customer deposit/topup balances
// This demonstrates a simple CSV-based balances file data/balances.csv with format: phone,balance
$data_file = __DIR__ . '/../data/balances.csv';
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $phone = $_POST['phone'] ?? '';
    $amount = floatval($_POST['amount'] ?? 0);
    $action = $_POST['action'] ?? 'add'; // add or set
    $lines = [];
    if(file_exists($data_file)) $lines = array_map('str_getcsv', file($data_file, FILE_IGNORE_NEW_LINES|FILE_SKIP_EMPTY_LINES));
    $found = false;
    foreach($lines as &$row){
        if($row[0] === $phone){
            $found = true;
            if($action === 'set') $row[1] = $amount;
            else $row[1] = floatval($row[1]) + $amount;
        }
    }
    if(!$found) $lines[] = [$phone, $amount];
    $out = [];
    foreach($lines as $r) $out[] = implode(',', $r);
    if(!is_dir(__DIR__ . '/../data')) mkdir(__DIR__ . '/../data', 0755, true);
    file_put_contents($data_file, implode("\n", $out));
    echo 'OK';
    exit;
}
?>
<h2>Atur Deposit Pelanggan</h2>
<form method="post">
Phone: <input name="phone"><br>
Amount: <input name="amount"><br>
Action: <select name="action"><option value="add">Tambah</option><option value="set">Set Saldo</option></select><br>
<button type="submit">Simpan</button>
</form>
