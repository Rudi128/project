<?php
// admin/bodcash.php - send messages to customers (minimal implementation)
// Expects POST with 'phone' and 'message'. Hook to existing send function if available.
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $phone = $_POST['phone'] ?? '';
    $msg = $_POST['message'] ?? '';
    // Simple log to data/bodcash_log.txt
    if(!is_dir(__DIR__ . '/../data')) mkdir(__DIR__ . '/../data', 0755, true);
    $log = date('c') . " | $phone | $msg\n";
    file_put_contents(__DIR__ . '/../data/bodcash_log.txt', $log, FILE_APPEND);
    echo 'SENT';
    exit;
}
?>
<h2>BodCash - Kirim Pesan ke Pelanggan</h2>
<form method="post">
Phone: <input name="phone"><br>
Message:<br>
<textarea name="message" rows="6" cols="80"></textarea><br>
<button type="submit">Kirim</button>
</form>
