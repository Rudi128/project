<?php
// admin/cs.php - manage customer support contacts
// Simple example: edits a JSON file data/cs_contacts.json
$data_file = __DIR__ . '/../data/cs_contacts.json';
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $contacts = isset($_POST['contacts']) ? json_decode($_POST['contacts'], true) : [];
    if(!is_dir(__DIR__ . '/../data')) mkdir(__DIR__ . '/../data', 0755, true);
    file_put_contents($data_file, json_encode($contacts, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));
    echo 'OK';
    exit;
}
$contacts = file_exists($data_file) ? json_decode(file_get_contents($data_file), true) : [];
?>
<h2>Atur CS</h2>
<form method="post">
<textarea name="contacts" rows="10" cols="80"><?php echo json_encode($contacts, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE); ?></textarea><br>
<button type="submit">Simpan</button>
</form>
