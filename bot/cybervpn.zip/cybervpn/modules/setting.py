from cybervpn import *
import requests
import subprocess
import asyncio
from telethon import Button, events
import time
import os

@bot.on(events.CallbackQuery(data=b'reboot'))
async def reboot(event):
    user_id = str(event.sender_id)
    async def reboot_(event):
        cmd = 'reboot'
        await event.edit("**Please Wait...**")
        subprocess.check_output(cmd, shell=True)
        await event.edit("""
**» Successfully Reboot Server**
""", buttons=[[Button.inline("𝙼𝚊𝚒𝚗 𝙼𝚎𝚗𝚞", "menu")]])

    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await reboot_(event)
        else:
            await event.answer('Akses Ditolak..!!', alert=True)

    except Exception as e:
        print(f'Error: {e}')



@bot.on(events.CallbackQuery(data=b'resx'))
async def resx(event):
    user_id = str(event.sender_id)

    async def resx_(event):
        await event.edit("**⏳ Please wait, restarting service...**")

        # Jalankan script secara non-blocking
        subprocess.Popen("bot-restart", shell=True)

        # Tunggu 10 detik sebelum mengirim pesan selesai
        await asyncio.sleep(10)

        await event.edit(
            "**✅ Restarting Service Done**",
            buttons=[[Button.inline("‹ 𝗠𝗮𝗶𝗻 𝗠𝗲𝗻𝘂 ›", b"menu")]]
        )

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await resx_(event)
        else:
            await event.answer('Akses Ditolak..!!', alert=True)

    except Exception as e:
        print(f'Error: {e}')

		
@bot.on(events.CallbackQuery(data=b'speedtest'))
async def speedtest(event):
    user_id = str(event.sender_id)
    async def speedtest_(event):
        cmd = 'speedtest-cli --share'.strip()
        await event.edit("**Please Wait...**")
        x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
        print(x)
        z = subprocess.check_output(cmd, shell=True).decode("utf-8")
        
        await event.respond(f"""
**
{z}
**
""", buttons=[[Button.inline("𝙼𝚊𝚒𝚗 𝙼𝚎𝚗𝚞", "menu")]])

    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await speedtest_(event)
        else:
            await event.answer('Akses Ditolak..!!', alert=True)

    except Exception as e:
        print(f'Error: {e}')

@bot.on(events.CallbackQuery(data=b'backup'))
async def backup(event):
    user_id = str(event.sender_id)

    async def backup_(event):
        async with bot.conversation(event.chat_id) as user:
            await event.respond('**Input Email:**')
            user_input = await user.wait_event(events.NewMessage(incoming=True, from_users=event.sender_id))
            email = user_input.raw_text
        
        await event.edit("**Please Wait...**")
        cmd = f'printf "%s\n" "{email}" | bot-backup'
        try:
            backup_output = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except subprocess.CalledProcessError:
            await event.respond("**Not Exist**")
        else:
            msg = f"""```{backup_output}```"""
            await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await backup_(event)
        else:
            await event.answer('Akses Ditolak..!!', alert=True)

    except Exception as e:
        print(f'Error: {e}')
        await event.respond(f"An error occurred: {e}")


@bot.on(events.CallbackQuery(data=b'restore'))
async def restore(event):
    async def restore_(event):
        async with bot.conversation(event.chat_id) as user:
            await event.respond('**Input Link Backup:**')
            user_input = await user.wait_event(events.NewMessage(incoming=True, from_users=event.sender_id))
            backup_link = user_input.raw_text
        await event.edit("**Please Wait...**")
        cmd = f'printf "%s\n" "{backup_link}" | bot-restore'
        try:
            restore_output = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except subprocess.CalledProcessError:
            await event.respond("**Link Not Exist**")
        else:
            msg = f"""```{restore_output}```"""
            await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    user_id = str(sender.id)

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await restore_(event)
        else:
            await event.answer('Akses Ditolak..!!', alert=True)

    except Exception as e:
        print(f'Error: {e}')
        await event.respond(f"An error occurred: {e}")


@bot.on(events.CallbackQuery(data=b'backer'))
async def backers(event):
    user_id = str(event.sender_id)
    async def backers_(event):
        inline = [
            [Button.inline("𝙱𝚊𝚌𝚔𝚞𝚙", "backup")], [Button.inline("𝚁𝚎𝚜𝚝𝚘𝚛𝚎", "restore")],
            [Button.inline("𝙼𝚊𝚒𝚗 𝙼𝚎𝚗𝚞", "menu")]
        ]
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
**◇━━━━━━━━━━━━━━━━◇**
     **◇⟨Backup & Restore ⟩◇**
**◇━━━━━━━━━━━━━━━━◇**
**» Service:** `Backup & Restore`
**» Hostname/IP:** `{DOMAIN}`
**» ISP:** `{z["isp"]}`
**» Country:** `{z["country"]}`
**◇━━━━━━━━━━━━━━━━━◇**
"""
        await event.edit(msg, buttons=inline)

    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await backers_(event)
        else:
            await event.answer('Akses Ditolak..!!', alert=True)

    except Exception as e:
        print(f'Error: {e}')


@bot.on(events.CallbackQuery(data=b'setting'))
async def settings(event):
    user_id = str(event.sender_id)
    async def settings_(event):
        inline = [
            [Button.inline("𝚂𝚙𝚎𝚎𝚍𝚝𝚎𝚜𝚝", "speedtest")], [Button.inline("𝙱𝚊𝚌𝚔𝚞𝚙 & 𝚁𝚎𝚜𝚝𝚘𝚛𝚎", "backer")],
[Button.inline("𝙴-𝚠𝚊𝚕𝚕𝚎𝚝 𝚂𝚎𝚝𝚝𝚒𝚗𝚐", "ewallet")],
            [Button.inline("𝚁𝚎𝚋𝚘𝚘𝚝 𝚂𝚎𝚛𝚟𝚎𝚛", "reboot")], [Button.inline("𝚁𝚎𝚜𝚝𝚊𝚛𝚝 𝚂𝚎𝚛𝚟𝚒𝚌𝚎", "resx")],
            [Button.inline("𝙼𝚊𝚒𝚗 𝙼𝚎𝚗𝚞", "menu")]
        ]
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
**◇━━━━━━━━━━━━━━━━◇**
           **◇⟨ Settings ⟩◇**
**◇━━━━━━━━━━━━━━━━◇**
**» Service:** `Settings`
**» Hostname/IP:** `{DOMAIN}`
**» ISP:** `{z["isp"]}`
**» Country:** `{z["country"]}`
**◇━━━━━━━━━━━━━━━━━◇**
"""
        await event.edit(msg, buttons=inline)

    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await settings_(event)
        else:
            await event.answer('Akses Ditolak..!!', alert=True)

    except Exception as e:
        print(f'Error: {e}')

